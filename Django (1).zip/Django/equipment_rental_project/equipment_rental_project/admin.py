from django.contrib import admin
from .models import Equipment, Rental

admin.site.register(Equipment)
admin.site.register(Rental)
